<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Regristrasi</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style-login.css">
</head>
<body>
    <div class="box">
        <div class="foto">
            <img src="img/Rasmus Nilsson.png" alt="">
        </div>
        <div class="form">
            
            <form action="proses-registrasi.php" method="POST">
                <?php
                if(isset($_GET['pesan'])){
                    if($_GET['pesan']=="gagal-tot"){?>
                    <div style="width:fit-content; display: flex; gap:6px; align-items: center; color: #f0f0f0; background: rgba(189, 39, 39, 0.40); backdrop-filter: blur(50px); border: 1px solid #BD2727; padding:12px; border-radius: 6px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2S2 6.477 2 12s4.477 10 10 10m3-6L9 8m0 8l6-8"/></svg>
                        Registrasi gagal
                    </div>
                <?php
                        }
                    }
                ?>
                <div class="input">
                    <p>Regristrasi</p>
                    <div class="username">
                        <label for="">Nama</label>
                        <input type="text" name="nama-lengkap" id="" required>
                    </div>
                    <div class="username">
                        <label for="">Email</label>
                        <input type="email" name="email" id="" required>
                    </div>
                    <div class="username">
                        <label for="">Username</label>
                        <input type="text" name="username" id="" required>
                    </div>
                    <div class="username">
                        <label for="">Alamat</label>
                        <input type="text" name="alamat" id="" required>
                    </div>
                    <div class="password">
                        <label for="">Password</label>
                        <input type="password" name="password" id="" required>
                    </div>
                    <input type="submit" value="Register">
                    <input type="button" onclick="location.href='login.php'" value="Sudah punya akun? Log in">
                </div>
            </form>
        </div>
    </div>
</body>
</html>