<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Beranda</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/tag.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <?php
        session_start();
        include "koneksi.php";
        $userid=$_SESSION['userid'];
        $username=mysqli_query($koneksi, "select * from user where userid='$userid'");
        $data_username=mysqli_fetch_array($username);
    ?>
    <div class="bar">
        <div class="bar-content">
            <div class="h1">
                <p>Se Gram</p>
            </div>
            <div class="icon">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 6.75c0-1.768 0-2.652.55-3.2C4.097 3 4.981 3 6.75 3c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 9.403 3 8.519 3 6.75m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 19.91 3 19.026 3 17.258M13.5 6.75c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2"/></svg>
                <span>Beranda</span>
            </div>
            <div class="icon" onclick="location.href='profile.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 18a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="7" r="3"/></g></svg>
                <span><?php echo $data_username['username'];?></span>
            </div>
        </div>
    </div>

    <nav>
        <div class="icon">
            <div onclick="location.href='beranda.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 6.75c0-1.768 0-2.652.55-3.2C4.097 3 4.981 3 6.75 3c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 9.403 3 8.519 3 6.75m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 19.91 3 19.026 3 17.258M13.5 6.75c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2"/></svg>
            </div>
            <div onclick="location.href='profile.php'" >
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M8 7a4 4 0 1 1 8 0a4 4 0 0 1-8 0m0 6a5 5 0 0 0-5 5a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3a5 5 0 0 0-5-5z" clip-rule="evenodd"/></svg>
            </div>
        </div>
    </nav>

    <section class="home fade-in">
        <div class="home-content">
            <?php
                $query=mysqli_query($koneksi, "select * from foto f JOIN user u ON f.userid=u.userid  ORDER BY tanggalunggah DESC");
                while($data=mysqli_fetch_array($query)){
            ?>
            <div class="content-post">
                <div class="profil">
                    <img src="img/profile.jpg" alt="">
                    <p><?php echo $data['username'];?></p>
                </div>
                <div class="gambar">
                    <img src="image/<?php echo $data['lokasifile']?>" alt="">
                </div>
                <div class="icon">
                    <div style="display:flex; gap:2px;">
                        
                            <?php
                                $fotoid=$data['fotoid'];
                                
                                $sql=mysqli_query($koneksi, "select * from likefoto where fotoid='$fotoid' and userid='$userid'");
                                $row=mysqli_fetch_array($sql);
                        

                                if(isset($row['fotoid']) && isset($row['userid'])){
                                    if($fotoid==$row['fotoid'] && $userid==$row['userid']){
                            ?>
                                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="#db2e2e" stroke="#db2e2e" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.071 13.142L13.414 18.8a2 2 0 0 1-2.828 0l-5.657-5.657A5 5 0 1 1 12 6.072a5 5 0 0 1 7.071 7.07"/></svg>
                            <?php
                                }

                                }else{?>
                                <a href="like-index.php?userid=<?php echo $userid;?>&fotoid=<?php echo $fotoid;?>" >
                                    <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.071 13.142L13.414 18.8a2 2 0 0 1-2.828 0l-5.657-5.657A5 5 0 1 1 12 6.072a5 5 0 0 1 7.071 7.07"/></svg>
                                </a>

                            <?php
                                }
                            
                            ?>
                        <sub for="" style="font-weight:600;"></sub>
                    </div>
                    <a href="tampilfoto2.php?fotoid=<?php echo $data['fotoid'];?>&userid=<?php echo $data['userid'];?>">
                        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 21a9 9 0 1 0-9-9c0 1.488.36 2.891 1 4.127L3 21l4.873-1c1.236.64 2.64 1 4.127 1"/></svg>
                    </a> 
                </div>
                <div class="like"> 
                        <?php
                            $sql2=mysqli_query($koneksi, "select count(fotoid) as jumlahlike from likefoto where fotoid='$fotoid'");
                            $row2=mysqli_fetch_array($sql2);
                        ?>
                    <label for="" style="font-weight:600;"><?php echo $row2['jumlahlike'];?> suka</label>
                    <p><?php echo $data['judulfoto'];?></p>
                </div>
                <div class="caption" style="gap:6px; display:grid;">
                    <p style="line-height:20px; letter-spacing: 0.4px; margin:0;">
                        <?php echo $data['deskripsifoto']?>
                    </p>
                    <div style="display:grid; gap:6px;">
                    <?php 
                        $komen=mysqli_query($koneksi, "select * from komentarfoto k JOIN user u ON k.userid=u.userid where fotoid='$fotoid' ORDER BY tanggalkomentar DESC LIMIT 2 ");
                        while($data_komen=mysqli_fetch_array($komen)){
                    ?>
                        <div style="display:flex; gap:6px; align-items:center;">
                            <span style="font-weight: 600; font-size:14px;">
                                <?php echo $data_komen['username']?>
                            </span>
                            <span style="font-size:14px;"><?php echo $data_komen['isikomentar']?></span>
                        </div>
                    <?php 
                        }
                    ?>
                    </div>
                    <div>
                        <span style="font-size: 10px; font-weight: 600;">
                            <?php echo $data['tanggalunggah'];?>
                        </span>
                    </div>
                </div>
            </div>
            <?php
            }
            ?>
        </div>
    </section>
</body>
</html>