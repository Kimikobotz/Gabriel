<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Login</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style-login.css">
</head>
<body>
    <div class="box">
        <div class="foto">
            <img src="img/Rasmus Nilsson.png" alt="">
        </div>
        <div class="form">
            
            <form action="proses-login.php" method="POST">
                <?php
                if(isset($_GET['pesan'])){
                    if($_GET['pesan']=="sukses-brok😁"){?>
                    <div style="width:fit-content; display: flex; gap:8px; align-items: center; color: #f0f0f0; background: rgba(105, 189, 39, 0.40); backdrop-filter: blur(50px); border: 1px solid #69BD27; padding:12px; border-radius: 6px;">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M3 17a1 1 0 0 1 1-1h1a1 1 0 0 1 1 1v3a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1zm3 3a1 1 0 0 0 1 1h3.756a1 1 0 0 0 .958-.713l1.2-3c.09-.303.133-.63-.056-.884C12.67 16.149 12.316 16 12 16h-2v-2.467a1.1 1.1 0 0 0-2.015-.61L6 16zm8-17v4a1 1 0 0 0 1 1h4"/><path d="M5 12.1V5a2 2 0 0 1 2-2h7l5 5v11a2 2 0 0 1-2 2h-2.3"/></g></svg>
                        Registrasi berhasil
                    </div>
                <?php
                        }elseif($_GET['pesan']=="gagal-tot"){?>
                        <div style="width:fit-content; display: flex; gap:6px; align-items: center; color: #f0f0f0; background: rgba(189, 39, 39, 0.40); backdrop-filter: blur(50px); border: 1px solid #BD2727; padding:12px; border-radius: 6px;">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2S2 6.477 2 12s4.477 10 10 10m3-6L9 8m0 8l6-8"/></svg>
                            Log in gagal
                        </div>
                <?php
                    }           
                }
                ?>
                <div class="input">
                    <p>Log In</p>
                    <div class="username">
                        <label for="">email</label>
                        <input type="email" name="email" id="" required>
                    </div>
                    <div class="password">
                        <label for="">Password</label>
                        <input type="password" name="password" id="" required>
                    </div>
                    <input type="submit" value="Log In">
                    <input type="button" onclick="location.href='regis.php'" value="Belum punya akun? Registrasi">
                </div>
            </form>
        </div>
    </div>
</body>
</html>