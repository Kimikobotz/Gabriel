<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Profile</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/tag.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body >
    <?php
        session_start();
        include "koneksi.php";$userid=$_SESSION['userid'];
        $username=mysqli_query($koneksi, "select * from user where userid='$userid'");
        $data_username=mysqli_fetch_array($username);
    ?>
    <div class="bar" >
        <div class="bar-content">
            <div class="h1">
                <p>Se Gram</p>
            </div>
            <div class="icon" onclick="location.href='beranda.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 6.75c0-1.768 0-2.652.55-3.2C4.097 3 4.981 3 6.75 3c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 9.403 3 8.519 3 6.75m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 19.91 3 19.026 3 17.258M13.5 6.75c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2"/></svg>
                <span>Beranda</span>
            </div>
            <div class="icon" onclick="location.href='profile.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 18a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="7" r="3"/></g></svg>
                <span><?php echo $data_username['username'];?></span>
            </div>
        </div>
    </div>

    <nav>
        <div class="icon">
            <div onclick="location.href='beranda.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 19v-8.5a1 1 0 0 0-.4-.8l-7-5.25a1 1 0 0 0-1.2 0l-7 5.25a1 1 0 0 0-.4.8V19a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1"/></svg>
            </div>
            <div onclick="location.href='tambahalbum.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M7.345 4.017a42.253 42.253 0 0 1 9.31 0c1.713.192 3.095 1.541 3.296 3.26a40.66 40.66 0 0 1 0 9.446c-.201 1.719-1.583 3.068-3.296 3.26a42.245 42.245 0 0 1-9.31 0c-1.713-.192-3.095-1.541-3.296-3.26a40.652 40.652 0 0 1 0-9.445a3.734 3.734 0 0 1 3.295-3.26M12 7.007a.75.75 0 0 1 .75.75v3.493h3.493a.75.75 0 1 1 0 1.5H12.75v3.493a.75.75 0 0 1-1.5 0V12.75H7.757a.75.75 0 0 1 0-1.5h3.493V7.757a.75.75 0 0 1 .75-.75" clip-rule="evenodd"/></svg>
            </div>
            <div onclick="location.href='profile.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M8 7a4 4 0 1 1 8 0a4 4 0 0 1-8 0m0 6a5 5 0 0 0-5 5a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3a5 5 0 0 0-5-5z" clip-rule="evenodd"/></svg>
            </div>
        </div>
    </nav>

    <section class="content-profil fade-in">
        <?php
            $userid=$_SESSION['userid'];
            $query=mysqli_query($koneksi, "select * from user where userid='$userid'");
            $data=mysqli_fetch_array($query);
        ?>
        <div class="foto-profil">
            <div class="kiri" style="">
                <img src="img/profile.jpg" alt="">
                <p><?php echo $data['username']?></p>
            </div>
            <div class="kanan" style="">
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3.082 13.945c-.529-.95-.793-1.426-.793-1.945c0-.519.264-.994.793-1.944L4.43 7.63l1.426-2.381c.559-.933.838-1.4 1.287-1.66c.45-.259.993-.267 2.08-.285L12 3.26l2.775.044c1.088.018 1.631.026 2.08.286c.45.26.73.726 1.288 1.659L19.57 7.63l1.35 2.426c.528.95.792 1.425.792 1.944c0 .519-.264.994-.793 1.944L19.57 16.37l-1.426 2.381c-.559.933-.838 1.4-1.287 1.66c-.45.259-.993.267-2.08.285L12 20.74l-2.775-.044c-1.088-.018-1.631-.026-2.08-.286c-.45-.26-.73-.726-1.288-1.659L4.43 16.37z"/><circle cx="12" cy="12" r="3"/></g></svg>
                    </a>
                    <a href="logout.php">
                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3.25a.75.75 0 0 1 0 1.5a7.25 7.25 0 0 0 0 14.5a.75.75 0 0 1 0 1.5a8.75 8.75 0 1 1 0-17.5"/><path fill="currentColor" d="M16.47 9.53a.75.75 0 0 1 1.06-1.06l3 3a.75.75 0 0 1 0 1.06l-3 3a.75.75 0 1 1-1.06-1.06l1.72-1.72H10a.75.75 0 0 1 0-1.5h8.19z"/></svg>
                    </a>
                </div>
            </div>
        </div>
        <div class="informasi-diri">
            <div class="flex">
                <p >
                    <?php echo $data['namalengkap'];?> | 
                </p>
            </div>
            <div class="flex">
                <p>
                    <?php echo $data['alamat'];?>
                </p>
            </div>
        </div>
        <div class="content">
            <div class="tambah" onclick="location.href='tambahalbum.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 40 40"><path fill="currentColor" d="m36.495 19.226l-15.732.012l.012-15.732a.763.763 0 0 0-1.525 0l-.012 15.733l-15.733.011a.763.763 0 0 0 0 1.525l15.732-.012l-.012 15.732c0 .204.082.4.223.538a.764.764 0 0 0 1.303-.538l.012-15.732l15.732-.012a.763.763 0 1 0 0-1.525"/></svg>
            </div>
            <div class="album">
               <?php
                    $userid=$_SESSION['userid'];
                    $query=mysqli_query($koneksi, "select * from album where userid='$userid' ORDER BY tanggaldibuat DESC");
                    while($data=mysqli_fetch_array($query)){
                ?>
                <div class="isi">
                    <div class="nama-album">
                        <div class="kiri" style="display:flex; gap:12px;">
                            <p><?php echo $data['namaalbum'];?></p>
                        </div>
                        <div class="kanan">
                            <button class="button">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 1024 1024"><path fill="currentColor" d="M456 231a56 56 0 1 0 112 0a56 56 0 1 0-112 0m0 280a56 56 0 1 0 112 0a56 56 0 1 0-112 0m0 280a56 56 0 1 0 112 0a56 56 0 1 0-112 0"/></svg>
                            </button>
                            <div class="opsi">
                                <a href="hapus-album.php?albumid=<?php echo $data['albumid'];?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 16 16"><path fill="currentColor" d="M14.5 4h-13c-.28 0-.5-.22-.5-.5s.22-.5.5-.5h13c.28 0 .5.22.5.5s-.22.5-.5.5"/><path fill="currentColor" d="m11.02 3.81l-.44-1.46a.504.504 0 0 0-.48-.36H5.9a.5.5 0 0 0-.48.36l-.44 1.46l-.96-.29l.44-1.46C4.65 1.42 5.23.99 5.9.99h4.2c.67 0 1.24.43 1.44 1.07l.44 1.46z"/><path fill="currentColor" d="M11.53 15H4.47c-.81 0-1.47-.64-1.5-1.45l-.34-9.87l1-.03l.34 9.87c0 .27.23.48.5.48h7.07c.27 0 .49-.21.5-.48l.34-9.87l1 .03l-.34 9.87c-.03.81-.69 1.45-1.5 1.45Z"/><path fill="currentColor" d="M6.5 11.62c-.28 0-.5-.22-.5-.5v-4c0-.28.22-.5.5-.5s.5.22.5.5v4c0 .28-.22.5-.5.5m3 0c-.28 0-.5-.22-.5-.5v-4c0-.28.22-.5.5-.5s.5.22.5.5v4c0 .28-.22.5-.5.5"/></svg>
                                    <span>hapus</span>
                                </a>
                                <a href="">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="1em" height="1em" viewBox="0 0 24 24"><g fill="none"><path d="M24 0v24H0V0zM12.593 23.258l-.011.002l-.071.035l-.02.004l-.014-.004l-.071-.035c-.01-.004-.019-.001-.024.005l-.004.01l-.017.428l.005.02l.01.013l.104.074l.015.004l.012-.004l.104-.074l.012-.016l.004-.017l-.017-.427c-.002-.01-.009-.017-.017-.018m.265-.113l-.013.002l-.185.093l-.01.01l-.003.011l.018.43l.005.012l.008.007l.201.093c.012.004.023 0 .029-.008l.004-.014l-.034-.614c-.003-.012-.01-.02-.02-.022m-.715.002a.023.023 0 0 0-.027.006l-.006.014l-.034.614c0 .012.007.02.017.024l.015-.002l.201-.093l.01-.008l.004-.011l.017-.43l-.003-.012l-.01-.01z"/><path fill="currentColor" d="M15 3c1.296 0 2.496.41 3.477 1.11l-9.134 9.133a1 1 0 1 0 1.414 1.414l9.134-9.134A5.977 5.977 0 0 1 21 9v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2zm6.657-.657a1 1 0 0 1 0 1.414L19.89 5.523a6.035 6.035 0 0 0-1.414-1.414l1.766-1.766a1 1 0 0 1 1.414 0Z"/></g></svg>
                                    <span>edit</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <img src="img/download (1).jpg" onclick="location.href='Foto.php?albumid=<?php echo $data['albumid'];?>'">
                </div>
                <?php
                    }
                ?>
            </div>
        </div>
    </section>
</body>
</html>