<?php
    include "koneksi.php";
    // mengambil data inputan data regis.php
    $nama_lengkap=$_POST['nama-lengkap'];
    $alamat=$_POST['alamat'];
    $username=$_POST['username'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    // memasukan data ke db_galeri
    $query=mysqli_query($koneksi,"insert into user (username,password,email,namalengkap,alamat) values ('$username','$password','$email','$nama_lengkap','$alamat')");

    // mengecheck query
    if($query){
        header("location:login.php?pesan=sukses-brok😁");
    } else{
        header("location:regis.php?pesan=gagal-tot");
    }
?>