<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Tambah Album</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style-tambahalbum.css">
</head>

<body style="background-color: #f0f0f0;">

    <div class="back" onclick="location.href='foto.php?albumid=<?php echo $_GET['albumid'];?>'">
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
            <path fill="currentColor"
                d="m4 10l-.707.707L2.586 10l.707-.707zm17 8a1 1 0 1 1-2 0zM8.293 15.707l-5-5l1.414-1.414l5 5zm-5-6.414l5-5l1.414 1.414l-5 5zM4 9h10v2H4zm17 7v2h-2v-2zm-7-7a7 7 0 0 1 7 7h-2a5 5 0 0 0-5-5z" />
        </svg>
        Back
    </div>
    <form action="proses-tambah-foto.php" method="POST" enctype="multipart/form-data">
        <?php
            session_start();
            $userid=$_SESSION['userid'];
            $albumid=$_GET['albumid'];
        ?>
        <input type="hidden" name="userid" value="<?php echo $userid;?>">
        <input type="hidden" name="albumid" value="<?php echo $albumid;?>">
        <div class="form">
            <H1>Tambah Foto</H1>
            <div class="file">
                <label for="" style="font-weight: 600;">Foto</label>
                <img id="output"/>
                <input type="file" accept="image/x-png,image/gif,image/jpeg"  name="image" id="file"  onchange="loadFile(event)">
            </div>
            <div class="nama-album">
                <label for="">Judul foto</label>
                <input type="text" name="judul-foto" id="">
            </div>
            <div class="caption">
                <label for="">Caption</label>
                <textarea name="caption" id="" cols="30" rows="10"></textarea>
            </div>
            <div class="submit">
                <input type="submit" value="Upload">
            </div>
        </div>
    </form>
</body>
</html>


<script>
var loadFile = function(event) {
    var image = document.getElementById('output');
    image.src = URL.createObjectURL(event.target.files[0]);
};
</script>