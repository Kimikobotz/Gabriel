<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    /* Tombol input file yang tersembunyi */
    input[type="file"] {
      display: none;
    }

    /* Gaya pada tombol yang mewakili tombol input file */
    label {
      background-color: #3498db;
      color: #fff;
      padding: 10px 15px;
      border-radius: 5px;
      cursor: pointer;
      font-family: Arial, sans-serif;
      font-size: 16px;
    }

    /* Gaya ketika kursor berada di atas tombol */
    label:hover {
      background-color: #2980b9;
    }
  </style>
</head>
<body>

  <!-- Tombol input file tersembunyi -->
  <input type="file" id="fileInput" />

  <!-- Label yang mewakili tombol input file -->
  <label for="fileInput">Pilih File</label>

</body>
</html>
