<?php
    include "koneksi.php";

    $userid=$_POST['userid'];
    $albumid=$_POST['albumid'];
    $judulfoto=$_POST['judul-foto'];
    $deskripsi=$_POST['caption'];
    $foto=$_FILES['image']['name'];
    $format=explode(".",$foto);
    $extensi=strtolower(end($format));
    $ukuranfoto=$_FILES['image']['size'];
    $file_temp=$_FILES['image']['tmp_name'];
    $ekstensi_diperbolehkan=array("jpg","png","gif","jpeg");

    if(in_array($extensi,$ekstensi_diperbolehkan)===true){
        if($ukuranfoto<10440700000){
            move_uploaded_file($file_temp,'image/'.$foto);
            $query=mysqli_query($koneksi, "insert into foto (judulfoto,deskripsifoto,tanggalunggah,lokasifile,albumid,userid) values ('$judulfoto','$deskripsi',NOW(),'$foto','$albumid','$userid')");
            if($query){
                header ("location:foto.php?albumid=".$albumid."?pesan=fotosukses");
            }else{
                header ("location:tambahfoto.php?albumid=".$albumid."?pesan=fotogagal");
            }
        }else{
            header ("location:tambahfoto.php?albumid=".$albumid."?pesan=ukuran-salah");
        }
    }else{
        header("location:tambahfoto.php?albumid=".$albumid."?pesan=extensisalah");
    }
?>