<?php
    $koneksi=mysqli_connect("localhost","root","","db_galeri");

    if (!$koneksi){
        echo "db tidak terkoneksi";
    }

?>