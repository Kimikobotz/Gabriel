<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    
    <title>Profile - Foto</title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/tag.css">
    <link rel="stylesheet" href="css/responsive.css">
</head>
<body>
    <div class="bar" >
        <div class="bar-content">
            <div class="h1">
                <p>Se Gram</p>
            </div>
            <div class="icon" onclick="location.href='beranda.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 6.75c0-1.768 0-2.652.55-3.2C4.097 3 4.981 3 6.75 3c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 9.403 3 8.519 3 6.75m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55C3 19.91 3 19.026 3 17.258M13.5 6.75c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2m0 10.507c0-1.768 0-2.652.55-3.2c.548-.55 1.432-.55 3.2-.55c1.768 0 2.652 0 3.2.55c.55.548.55 1.432.55 3.2c0 1.768 0 2.652-.55 3.2c-.548.55-1.432.55-3.2.55c-1.768 0-2.652 0-3.2-.55c-.55-.548-.55-1.432-.55-3.2"/></svg>
                <span>Beranda</span>
            </div>
            <div class="icon" onclick="location.href='profile.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24px" height="24px" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path stroke-linejoin="round" d="M4 18a4 4 0 0 1 4-4h8a4 4 0 0 1 4 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2z"/><circle cx="12" cy="7" r="3"/></g></svg>
                <span>Profil</span>
            </div>
        </div>
    </div>

    <nav>
        <div class="icon">
            <div onclick="location.href='beranda.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 19v-8.5a1 1 0 0 0-.4-.8l-7-5.25a1 1 0 0 0-1.2 0l-7 5.25a1 1 0 0 0-.4.8V19a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1v-3a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v3a1 1 0 0 0 1 1h4a1 1 0 0 0 1-1"/></svg>
            </div>
            <div onclick="location.href='tambahfoto.php?albumid=<?php echo $_GET['albumid'];?>'">
                <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M7.345 4.017a42.253 42.253 0 0 1 9.31 0c1.713.192 3.095 1.541 3.296 3.26a40.66 40.66 0 0 1 0 9.446c-.201 1.719-1.583 3.068-3.296 3.26a42.245 42.245 0 0 1-9.31 0c-1.713-.192-3.095-1.541-3.296-3.26a40.652 40.652 0 0 1 0-9.445a3.734 3.734 0 0 1 3.295-3.26M12 7.007a.75.75 0 0 1 .75.75v3.493h3.493a.75.75 0 1 1 0 1.5H12.75v3.493a.75.75 0 0 1-1.5 0V12.75H7.757a.75.75 0 0 1 0-1.5h3.493V7.757a.75.75 0 0 1 .75-.75" clip-rule="evenodd"/></svg>
            </div>
            <div onclick="location.href='profile.php'">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path fill="currentColor" fill-rule="evenodd" d="M8 7a4 4 0 1 1 8 0a4 4 0 0 1-8 0m0 6a5 5 0 0 0-5 5a3 3 0 0 0 3 3h12a3 3 0 0 0 3-3a5 5 0 0 0-5-5z" clip-rule="evenodd"/></svg>
            </div>
        </div>
    </nav>
    <?php
        session_start();
        include "koneksi.php";
    ?>
    <section class="content-profil">
        <?php
            $userid=$_SESSION['userid'];
            $query=mysqli_query($koneksi, "select * from user where userid='$userid'");
            $data=mysqli_fetch_array($query);
        ?>
        <div class="foto-profil">
            <div class="kiri" style="">
                <img src="img/profile.jpg" alt="">
                <p><?php echo $data['username']?></p>
            </div>
            <div class="kanan" style="">
                <div>
                    <a href="">
                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24"><g fill="none" stroke="currentColor" stroke-width="1.5"><path d="M3.082 13.945c-.529-.95-.793-1.426-.793-1.945c0-.519.264-.994.793-1.944L4.43 7.63l1.426-2.381c.559-.933.838-1.4 1.287-1.66c.45-.259.993-.267 2.08-.285L12 3.26l2.775.044c1.088.018 1.631.026 2.08.286c.45.26.73.726 1.288 1.659L19.57 7.63l1.35 2.426c.528.95.792 1.425.792 1.944c0 .519-.264.994-.793 1.944L19.57 16.37l-1.426 2.381c-.559.933-.838 1.4-1.287 1.66c-.45.259-.993.267-2.08.285L12 20.74l-2.775-.044c-1.088-.018-1.631-.026-2.08-.286c-.45-.26-.73-.726-1.288-1.659L4.43 16.37z"/><circle cx="12" cy="12" r="3"/></g></svg>
                    </a>
                    <a href="logout.php">
                        <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 24 24"><path fill="currentColor" d="M12 3.25a.75.75 0 0 1 0 1.5a7.25 7.25 0 0 0 0 14.5a.75.75 0 0 1 0 1.5a8.75 8.75 0 1 1 0-17.5"/><path fill="currentColor" d="M16.47 9.53a.75.75 0 0 1 1.06-1.06l3 3a.75.75 0 0 1 0 1.06l-3 3a.75.75 0 1 1-1.06-1.06l1.72-1.72H10a.75.75 0 0 1 0-1.5h8.19z"/></svg>
                    </a>
                </div>
            </div>
        </div>
        <div class="informasi-diri">
            <div class="flex">
                <p >
                    <?php echo $data['namalengkap'];?> |
                </p>
            </div>
            <div class="flex">
                <p>
                    <?php echo $data['alamat'];?>
                </p>
            </div>
        </div>
        <?php
            $albumid=$_GET['albumid'];
        ?>
        <div class="content fade-in">
            <a class="tambah" href="tambahfoto.php?albumid=<?php echo $albumid;?>">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 40 40"><path fill="currentColor" d="m36.495 19.226l-15.732.012l.012-15.732a.763.763 0 0 0-1.525 0l-.012 15.733l-15.733.011a.763.763 0 0 0 0 1.525l15.732-.012l-.012 15.732c0 .204.082.4.223.538a.764.764 0 0 0 1.303-.538l.012-15.732l15.732-.012a.763.763 0 1 0 0-1.525"/></svg>
            </a>
            <hr class="hr">
            <?php
                $query=mysqli_query($koneksi, "select * from album where albumid='$albumid'");
                $data=mysqli_fetch_array($query);
            ?>
            <div class="judul"><?php echo $data['namaalbum'];?></div>

            <div class="foto">
                <?php
                    $userid=$_SESSION['userid'];
                    $albumid=$_GET['albumid'];
                    $query=mysqli_query($koneksi, "select * from foto where userid='$userid' and albumid='$albumid' ORDER BY tanggalunggah DESC");
                    while($data=mysqli_fetch_array($query)){
                ?>
                <div class="isi"  onclick="location.href='tampilfoto.php?fotoid=<?php echo $data['fotoid'];?>&albumid=<?php echo $data['albumid'];?>'">
                    <img src="image/<?php echo $data['lokasifile'];?>" alt="<?php echo $data['lokasifile'];?>">
                </div>
                <?php
                    }
                ?>
            </div>
        </div>
    </section>
</body>
</html>