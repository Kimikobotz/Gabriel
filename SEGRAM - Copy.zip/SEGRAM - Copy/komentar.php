<?php
    include "koneksi.php";

    $fotoid=$_POST['fotoid'];
    $userid=$_POST['userid'];
    $isikomentar=$_POST['komentar'];

    $query=mysqli_query($koneksi, "insert into komentarfoto (fotoid,userid,isikomentar,tanggalkomentar) values ('$fotoid', '$userid', '$isikomentar', NOW())");
    
    if($query){
        header("location:tampilfoto.php?fotoid=".$fotoid);
    }else{
        header("location:tampilfoto.php?fotoid=".$fotoid);
    }
?>