<?php
    include "koneksi.php";

    $userid=$_POST['userid'];

    $nama_album=$_POST['nama-album'];
    $caption=$_POST['caption'];
    $tanggal=$_POST['tanggal'];

    $query=mysqli_query($koneksi,"insert into album (namaalbum,deskripsi,tanggaldibuat,userid) values ('$nama_album','$caption','$tanggal','$userid')");

    if($query){
        header("location:profile.php");
    }else{
        header("location:tambahalbum.php");
    }
?>