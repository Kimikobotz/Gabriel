<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href="img/favicon_io/favicon.ico" type="image/x-icon">
    <?php
        session_start();
        include "koneksi.php";
        $userid=$_SESSION['userid'];
        $fotoid=$_GET['fotoid'];
        $sql=mysqli_query($koneksi, "select * from foto f JOIN user u ON f.userid=u.userid where fotoid='$fotoid'");
        $row=mysqli_fetch_array($sql);
    ?>
    <title><?php echo $row['judulfoto'];?></title>
    
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/style-tampilfoto.css">
    <link rel="stylesheet" href="css/responsive-tampil-foto.css">
</head>
<body class="fade-in">
    
    <div class="back" onclick="location.href='beranda.php'">
        <svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24">
            <path fill="currentColor"
                d="m4 10l-.707.707L2.586 10l.707-.707zm17 8a1 1 0 1 1-2 0zM8.293 15.707l-5-5l1.414-1.414l5 5zm-5-6.414l5-5l1.414 1.414l-5 5zM4 9h10v2H4zm17 7v2h-2v-2zm-7-7a7 7 0 0 1 7 7h-2a5 5 0 0 0-5-5z" />
        </svg>
    </div>
    
    <div class="conten">
        <?php
            $fotoid=$_GET['fotoid'];
            $query=mysqli_query($koneksi, "select * from foto f JOIN user u ON f.userid=u.userid where fotoid='$fotoid'");
            $data=mysqli_fetch_array($query);
        ?>
        <div class="conten-kiri">
            <img src="image/<?php echo $data['lokasifile'];?>" alt="" style="width: 100%; height: 100%; object-fit: contain; border-radius: 24px;">
        </div>
        <div class="conten-kanan">
            <div class="isi">
                <div class="flex">
                    <div class="profil">
                        <img src="img/profile.jpg" alt="">
                        <h5 style="margin:0;"><?php echo $data['username'];?></h5>
                    </div>
                </div>
                <div class="caption">
                    <h1 style="margin:0; line-height: 42px;">
                        <?php echo $data['judulfoto'];?>
                    </h1>
                    <p style="width: 90%; line-height:20px; letter-spacing: 0.4px;">
                        <?php echo $data['deskripsifoto'];?>
                    </p>
                </div>
                <div class="komen-field">
                    
                    <form action="komentar2.php" method="POST">
                    <input type="hidden" name="fotoid" value="<?php echo $fotoid;?>">
                    <input type="hidden" name="userid" value="<?php echo $userid;?>">
                        <div class="komen" style="display: flex; width: ; background: #fff; border-radius: 12px; padding:6px; position:absolute; z-index:10;">
                            <input type="text" name="komentar" id="" style="width: 430px; outline:none; border:none; padding:6px; border-radius:6px; ;" placeholder="ketik">
                            <input type="submit" value="kirim" style="width: 60px; outline:none; border:none; padding:6px; border-radius:6px;">
                        </div>
                    </form>
                    <div class="margin">
                        <?php
                            $sql3=mysqli_query($koneksi, "select * from komentarfoto k JOIN user u ON k.userid=u.userid where fotoid='$fotoid' ORDER BY tanggalkomentar DESC");
                            while($row3=mysqli_fetch_array($sql3)){
                        ?>
                        <div class="komentator">
                            <div class="profile">
                                <img src="img/profile.jpg" alt="">
                                <span><?php echo $row3['username'];?></span>
                            </div>
                            <div class="komentar">
                                <p>
                                    <?php echo $row3['isikomentar'];?>
                                </p>
                            </div>
                        </div>
                        <?php
                            }
                        ?>
                    </div>
                </div>
                <div class="icon">
                    <div class="hati">
                        <div class="icon">
                            
                                <?php
                                    $sql=mysqli_query($koneksi, "select * from likefoto where fotoid='$fotoid' and userid='$userid'");
                                    $row=mysqli_fetch_array($sql);
                            

                                    if(isset($row['fotoid']) && isset($row['userid'])){
                                        if($fotoid==$row['fotoid'] && $userid==$row['userid']){
                                ?>
                                    <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24"><path fill="#db2e2e" stroke="#db2e2e" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.071 13.142L13.414 18.8a2 2 0 0 1-2.828 0l-5.657-5.657A5 5 0 1 1 12 6.072a5 5 0 0 1 7.071 7.07"/></svg>
                                <?php
                                    }

                                    }else{?>
                                    <a href="like.php?userid=<?php echo $userid;?>&fotoid=<?php echo $fotoid;?>" >
                                        <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.071 13.142L13.414 18.8a2 2 0 0 1-2.828 0l-5.657-5.657A5 5 0 1 1 12 6.072a5 5 0 0 1 7.071 7.07"/></svg>
                                    </a>

                                <?php
                                    }
                                
                                ?>
                            <?php
                                $sql2=mysqli_query($koneksi, "select count(fotoid) as jumlahlike from likefoto where fotoid=$fotoid");
                                $row2=mysqli_fetch_array($sql2);
                            ?>
                            <sub for="" style="font-weight:600;"><?php echo $row2['jumlahlike'];?> </sub>
                        </div>
                        
                        <div class="icon">
                            <a>
                                <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24"><path fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 21a9 9 0 1 0-9-9c0 1.488.36 2.891 1 4.127L3 21l4.873-1c1.236.64 2.64 1 4.127 1"/></svg>
                                
                            </a>
                            <?php
                                    $sql4=mysqli_query($koneksi, "select count(fotoid) as jumlahkomentar from komentarfoto where fotoid=$fotoid");
                                    $row4=mysqli_fetch_array($sql4);
                                ?>
                            <sub for="" style="font-weight:600;"><?php echo $row4['jumlahkomentar'];?></sub>
                       </div>
                    </div>
                </div>
                <div class="like">
                    
                </div>
            </div>
        </div>
    </div>
</body>
</html>